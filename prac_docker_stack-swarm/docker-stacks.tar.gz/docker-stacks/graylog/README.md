Portainer Control Panel.

Suggested deployment:

  After configuring docker swarm cluster, deploy this portainer stack from the commandline.

  The other stacks can be deployed from portainer, so you can tweak them afterwards from its UI, but you keep portainer safe from breaking it.
